<?php
// Feature Management File

// Load enabled features
function nde_manage_features() {
    $features = nde_get_feature_list();
    foreach ($features as $feature) {
        $is_enabled = get_option( 'nde_' . $feature['slug'], 'no' );
        if ($is_enabled === 'yes') {
            nde_load_feature( $feature['slug'] );
        }
    }
}

// Load the feature if it's enabled
function nde_load_feature( $slug ) {
    $feature_dir = NDE_PLUGIN_DIR . 'features/' . $slug;
    $feature_file = $feature_dir . '/' . $slug . '.php';

    if (file_exists($feature_file)) {
        require_once($feature_file);
    }
}

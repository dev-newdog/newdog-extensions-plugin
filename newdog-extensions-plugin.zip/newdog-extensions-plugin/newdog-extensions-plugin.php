<?php
/**
 * Plugin Name: NewDog Extensions Plugin
 * Description: A modular plugin with multiple features that can be enabled or disabled.
 * Version: 1.0
 * Author: Your Name
 */

// Prevent direct access to this file
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Define plugin path constants
define('NDE_PLUGIN_DIR', plugin_dir_path( __FILE__ ));
define('NDE_PLUGIN_URL', plugin_dir_url( __FILE__ ));

// Include feature management
require_once( NDE_PLUGIN_DIR . 'includes/feature-management.php' );

// Initialize the plugin
function nde_initialize_plugin() {
    // Initialize feature management (this will load enabled features)
    nde_manage_features();
}
add_action( 'plugins_loaded', 'nde_initialize_plugin' );

// Add admin menu for managing features
function nde_plugin_menu() {
    add_menu_page( 
        'NewDog Extensions Settings', 
        'NewDog Extensions', 
        'manage_options', 
        'nde-settings', 
        'nde_plugin_settings_page',
        'dashicons-admin-plugins',
        30
    );
}
add_action( 'admin_menu', 'nde_plugin_menu' );

// Create the settings page
function nde_plugin_settings_page() {
    ?>
    <div class="wrap">
        <h1>NewDog Extensions Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields( 'nde_plugin_options_group' );
            do_settings_sections( 'nde-settings' );
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

// Register plugin settings
function nde_register_settings() {
    // Define feature settings section
    add_settings_section( 
        'nde_feature_section', 
        'Enable Features', 
        null, 
        'nde-settings' 
    );

    // Add settings for each feature
    $features = nde_get_feature_list();
    foreach ($features as $feature) {
        add_settings_field(
            'nde_' . $feature['slug'], 
            $feature['name'], 
            'nde_feature_checkbox', 
            'nde-settings', 
            'nde_feature_section', 
            array('feature' => $feature)
        );
        register_setting( 'nde_plugin_options_group', 'nde_' . $feature['slug'] );
    }
}
add_action( 'admin_init', 'nde_register_settings' );

// Display the checkbox for each feature
function nde_feature_checkbox($args) {
    $option = get_option( 'nde_' . $args['feature']['slug'], 'no' );
    ?>
    <input type="checkbox" name="nde_<?php echo esc_attr( $args['feature']['slug'] ); ?>" value="yes" <?php checked( $option, 'yes' ); ?> />
    <?php
}

// Get the list of available features
function nde_get_feature_list() {
    $features = array(
        array('slug' => 'feature1', 'name' => 'Feature 1'),
        array('slug' => 'feature2', 'name' => 'Feature 2'),
        array('slug' => 'feature3', 'name' => 'Prevent Add to Cart on Refresh'),
        array('slug' => 'wooextensions', 'name' => 'product extensions'),
        array('slug' => 'imprint-type', 'name' => 'Imprint Type'),
        array('slug' => 'imprint-method', 'name' => 'Imprint Method')
    );
    return $features;
}

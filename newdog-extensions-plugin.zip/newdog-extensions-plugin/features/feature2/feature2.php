<?php
// Feature 2 Implementation

function feature2_functionality() {
    // Code for Feature 1
    echo 'Feature 2 is active!';
}

add_action('wp_footer', 'feature2_functionality');
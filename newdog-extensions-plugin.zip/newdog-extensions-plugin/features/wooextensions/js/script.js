const bigFrontAttr = document.querySelector(".silkscreen_Locations_dropdown #big-front");
const leftChest = document.querySelector(".silkscreen_Locations_dropdown #left-chest");
const rightChest = document.querySelector(".silkscreen_Locations_dropdown #right-chest");
const apparelBigFront = document.querySelector('.apparel-bigfront');
const apparelLeftChest = document.querySelector(".apparel-leftchest");
const apparelRightChest = document.querySelector(".apparel-rightchest");

bigFrontAttr.addEventListener('change', (e) => {
    const isBigFrontSelected = e.target.value > 0;

    apparelBigFront.style.display = isBigFrontSelected ? "block" : "none";
    leftChest.disabled = isBigFrontSelected;
    rightChest.disabled = isBigFrontSelected;

    if (isBigFrontSelected) {
        apparelLeftChest.style.display = "none";
        apparelRightChest.style.display = "none";
        leftChest.value = 0;
        rightChest.value = 0;
    }
});


function silkscreenLocator(attrIdName, locatorClass) {

    let attribute = document.querySelector(`.silkscreen_Locations_dropdown ${attrIdName}`);

    attribute.addEventListener('change', e => {
        document.querySelector(locatorClass).style.display = "none"
        if (e.target.value > 0) {
            document.querySelector(locatorClass).style.display = "block"
        }
    });
}

silkscreenLocator("#left-chest", ".apparel-leftchest");
silkscreenLocator("#right-chest", ".apparel-rightchest");
silkscreenLocator("#left-sleeve", ".apparel-leftsleeve");
silkscreenLocator("#right-sleeve", ".apparel-rightsleeve");
silkscreenLocator("#tag", ".apparel-tag");
silkscreenLocator("#big-back", ".apparel-bigback");
<?php
/*
Plugin Name: WooCommerce Extensions
Description: A plugin to add additional features such add product JS.
Version: 1.0
Author: Shoaib
*/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_action( 'wp_enqueue_scripts', 'wooextension_enqueue_scripts' );

function wooextension_enqueue_scripts() {
    if ( is_product() ) {
        wp_enqueue_script( 'my-custom-script', plugin_dir_url( __FILE__ ) . 'js/script.js', array('jquery'), null, true );
        wp_enqueue_style( 'my-custom-styles', plugin_dir_url( __FILE__ ) . 'css/styles.css');
    }
}


function silkscreen_Locations_dropdowns($label, $id, $name) {

    echo '<div class="silkscreen_Locations_dropdown">';
    echo '<label for="'. $id .'">' . $label . ': </label>';
    echo '<select id="'. $id .'" name="' . $name . '">';
    echo '<option value="">Select...</option>';
    for ($i = 0; $i <= 6; $i++) {
        echo '<option value="' . esc_attr($i) . '">' . esc_html($i) . '</option>';
    }
    echo '</select>';
    echo '</div>';
}

# Silkscreen simulator template form
add_action('woocommerce_before_variations_form', 'add_silkscreen_Locations', 15);

function add_silkscreen_Locations() {
    ?>
    <div class="silkscreen-locations">
        <h4>Select Silkscreen Locations and Number of Print Colors.</h4>
        <div class="silkscreen-apparel">
            <div class="apparel-front">
                
                <?php
                // Define an array of silkscreen location class names
                $silkscreenClassNames = ['apparel-bigfront', 'apparel-rightchest', 'apparel-leftchest','apparel-rightsleeve', 'apparel-leftsleeve'];
                
                // Loop through the array and generate the divs
                foreach ($silkscreenClassNames as $class) {
                    echo "<div class=\"$class\"></div>";
                }
                
                echo '<img src="' . plugin_dir_url(__FILE__) . 'images/front.png" alt="front side of t-shirt">'; ?>
            </div>
            <div class="apparel-back">
                <div class="apparel-tag"></div>
                <div class="apparel-bigback"></div>
                <?php echo '<img src="' . plugin_dir_url(__FILE__) . 'images/back.png" alt="back side of t-shirt">'; ?>
            </div>
        </div>
    </div>
    <?php 
    echo silkscreen_Locations_dropdowns("Big Front", "big-front", "attribute_big_front");
    echo silkscreen_Locations_dropdowns("Left Chest", "left-chest", "attribute_left_chest");
    echo silkscreen_Locations_dropdowns("Right Chest", "right-chest", "attribute_right_chest");
    echo silkscreen_Locations_dropdowns("Left Sleeve", "left-sleeve", "attribute_left_sleeve");
    echo silkscreen_Locations_dropdowns("Right Sleeve", "right-sleeve", "attribute_right_sleeve");
    echo silkscreen_Locations_dropdowns("Big Back", "big-back", "attribute_big_back");
    echo silkscreen_Locations_dropdowns("Tag", "tag", "attribute_tag");
}

global $silkscreen_dropdown_value;
$silkscreen_dropdown_value = array(
    "Big Front"=>"attribute_big_front",
    "Left Chest"=>"attribute_left_chest",
    "Right Chest"=>"attribute_right_chest",
    "Left Sleeve"=>"attribute_left_sleeve",
    "Right Sleeve"=>"attribute_right_sleeve",
    "Big Back"=>"attribute_big_back",
    "Tag"=>"attribute_tag",
);

# save the selected values
add_filter('woocommerce_add_cart_item_data', 'save_silkscreen_dropdown_value', 10, 3);

function save_silkscreen_dropdown_value($cart_item_data, $product_id, $variation_id) {
    // Iterate through the array
    global $silkscreen_dropdown_value;
    foreach ($silkscreen_dropdown_value as $label => $attribute) {
        
        if (isset($_POST[$attribute])) {
            $cart_item_data[$attribute] = sanitize_text_field($_POST[$attribute]);
        } else {
            $cart_item_data[$attribute] = 0;
        }
    }
    return $cart_item_data;
}

# display the values on the checkout pages
add_filter('woocommerce_get_item_data', 'display_silkscreen_dropdown_value_cart', 10, 2);

function display_silkscreen_dropdown_value_cart($item_data, $cart_item) {
    global $silkscreen_dropdown_value;
    foreach ($silkscreen_dropdown_value as $label => $attribute) {
        if (isset($cart_item[$attribute])) {
            $item_data[] = array(
                'name' => $label,
                'value' => esc_html($cart_item[$attribute]),
            );
        }
    }
    return $item_data;
}

# Save the Value in Order Metadata
add_action('woocommerce_checkout_create_order_line_item', 'save_silkscreen_dropdown_value_in_order_items', 10, 4);

function save_silkscreen_dropdown_value_in_order_items($item, $cart_item_key, $values, $order) {
    global $silkscreen_dropdown_value;
    foreach ($silkscreen_dropdown_value as $label => $attribute) {
        if (isset($values[$attribute])) {
            $item->add_meta_data($attribute, $values[$attribute]);
        }
    }
}


add_filter('woocommerce_quantity_input_args', 'set_minimum_quantity', 10, 2);

function set_minimum_quantity($args, $product) {
    
    $product = wc_get_product(get_the_ID());
    $terms = get_the_terms($product->get_id(), 'product_cat');
    
    if ($terms && ! is_wp_error($terms)) {
        foreach ($terms as $term) {
            if ($term->name == 'sweatshirts') {
                $minQuantity = 24;
            } elseif ($term->name == 'mentshirts') {
                $minQuantity = 25;
            }
        }
    }
    
    $args['min_value'] = $minQuantity; // Set the minimum quantity here
    $args['input_value'] = $minQuantity; // Set the default input value
    
    return $args;
    
}


add_action('woocommerce_before_add_to_cart_quantity', 'custom_quantity_label');

function custom_quantity_label() {
    echo '<label for="quantity">' . __("Min. Quantity: ", 'your-text-domain') . '</label>';
}


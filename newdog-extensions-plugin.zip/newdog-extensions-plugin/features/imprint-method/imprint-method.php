<?php

// Register Custom Post Type
function register_imprintmethod_post_type() {
    $labels = array(
        'name'                  => _x( 'Imprint Methods', 'Post Type General Name'),
        'singular_name'         => _x( 'Imprint Method', 'Post Type Singular Name'),
        'menu_name'             => __( 'Imprint Methods'),
        'name_admin_bar'        => __( 'Imprint Method'),
        'archives'              => __( 'Imprint Method Archives'),
        'attributes'            => __( 'Imprint Method Attributes'),
        'parent_item_colon'     => __( 'Parent Imprint Method:'),
        'all_items'             => __( 'All Imprint Methods'),
        'add_new_item'          => __( 'Add New Imprint Method'),
        'add_new'               => __( 'Add New'),
        'new_item'              => __( 'New Imprint Method'),
        'edit_item'             => __( 'Edit Imprint Method'),
        'update_item'           => __( 'Update Imprint Method'),
        'view_item'             => __( 'View Imprint Method'),
        'view_items'            => __( 'View Imprint Methods'),
        'search_items'          => __( 'Search Imprint Method'),
        'not_found'             => __( 'Not found'),
        'not_found_in_trash'    => __( 'Not found in Trash'),
        'featured_image'        => __( 'Featured Image'),
        'set_featured_image'    => __( 'Set featured image'),
        'remove_featured_image' => __( 'Remove featured image'),
        'use_featured_image'    => __( 'Use as featured image'),
        'insert_into_item'      => __( 'Insert into imprint Method'),
        'uploaded_to_this_item' => __( 'Uploaded to this imprint Method'),
        'items_list'            => __( 'Imprint Method list'),
        'items_list_navigation' => __( 'Imprint Methods list navigation'),
        'filter_items_list'     => __( 'Filter imprint method list'),
    );
    
    $args = array(
        'label'                 => __( 'Imprint Method' ),
        'description'           => __( 'Post type for Imprint Methods.' ),
        'labels'                => $labels,
        'supports'              => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'custom-fields' ),
        // 'taxonomies'            => array( 'category', 'post_tag' ), // Default taxonomies
        'hierarchical'          => false,
        'public'                => true,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'show_in_admin_bar'     => true,
        'show_in_nav_menus'     => true,
        'can_export'            => true,
        'has_archive'           => true,
        'exclude_from_search'   => false,
        'publicly_queryable'    => true,
        'rewrite'               => array( 'slug' => 'imprint-method' ), // Custom permalink structure
        'capability_type'       => 'post',
        'menu_icon'             => 'dashicons-admin-generic',
    );

    register_post_type( 'imprint-method', $args );
}

// Hook into the 'init' action to register the post type
add_action( 'init', 'register_imprintmethod_post_type', 0 );
